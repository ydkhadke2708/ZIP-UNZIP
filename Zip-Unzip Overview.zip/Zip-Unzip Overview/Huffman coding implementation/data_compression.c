#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include "freq_list.h"
#include "min_heap.h"
#include "data_compression.h"



freq_node* get_node(){
    freq_node *newnode = (freq_node*)malloc(sizeof(freq_node));

    if(newnode){
        newnode->freq = 0;
        newnode->symbol = '\0';
        newnode->next = NULL;
        newnode->left =newnode->right = newnode->parent = NULL ;
        newnode->is_leaf = 0;
    }
    else
        return NULL;
    return newnode;
}


freq_node* create_tree(freq_list *l ){

    pqueue q;
    init_pqueue(&q);

    freq_node *p,*m;
    p = *l;
    int len =0;
    while(p){
        m = p;
        p = p->next;
        m->next = NULL;
        insert_pqueue(&q,m);
        len++;
    }
    freq_node* left , *right;
    freq_node* top;

    //////////////////////////////////////////////////////////////
    for(int j = 0 ; j< len-1 ; j++){

        left = pop_pqueue(&q);
        right = pop_pqueue(&q);
        top = get_node();
        top->left = left;
        top->right = right ;
        left->parent = top;
        right->parent = top;
        top->freq = left->freq + right->freq ;
        insert_pqueue(&q,top);
    }


    return pop_pqueue(&q);
}


void generate_codebook(freq_node* root, int depth, char* codebook) {

	if (root->is_leaf) { // we reach the bottom of the encode tree
		int len = depth;
		char symbol = root->symbol;
		// add 0 at the end of string
		*(codebook + ((size_t)symbol) * len_of_bits + len) = 0;
		// start from the bottom (leaf) to the top (root)
		freq_node* parent = root->parent;
		while ((parent != NULL) && (len > 0)) {
			// root is left of parent
			if (root == parent->left) {
				*(codebook + ((size_t)symbol) *  len_of_bits + (--len)) = '0';
			}
			else { // root is right of parent
				*(codebook + ((size_t)symbol) *  len_of_bits + (--len)) = '1';
			}
			root = parent;
			parent = root->parent;

		}
		// display
		//printf("built code: (%c, %s)\n", symbol, codebook + ((size_t)symbol) *  len_of_bits);
	}
	else {
		generate_codebook(root->left, depth + 1, codebook);
		generate_codebook(root->right, depth + 1, codebook);
	}
}

void write_codebook(FILE* f_out, char* codebook,unsigned int size) {
	int i = 0;
	fprintf(f_out,"%u\n",size);
	for (i = 0; i < no_of_symbols; i++) {
		if (*(codebook + i * len_of_bits)) { // when the strcode of symbol char i is not empty
			fprintf(f_out, "#%c %s\n", i, codebook + i * len_of_bits);
		}
	}
}


void write_encode_stream_from_file(FILE* f_in, FILE* f_out, char* codebook) {
	char c;
	unsigned char buffer = 0;
	unsigned count = 0;
	unsigned char bit ;
	int i = 0;
	while (!feof(f_in)) {
		// fscanf_s(f_in, "%c", &c, 1);
		c = getc(f_in);
		if(c == EOF) break;
		i = 0;
		bit = *(codebook + (size_t)c * len_of_bits + i) ;
		while (bit != 0){
             buffer <<=1;
            if (bit == '1'){
                buffer |= 1;
            }
            count++;
            if (count == 8){
                fwrite(&buffer,sizeof(buffer),1,f_out);
                buffer = 0;
                count = 0;
            }
            i++;
            bit = *(codebook + (size_t)c * len_of_bits + i) ;
		}
	}
	if (count < 8){
        int j = 8 - count ;
        while (j != 0){
            buffer <<= 1;
            j--;
        }
        fwrite(&buffer,sizeof(buffer),1,f_out);
	}
}
/*
void write_encode_stream_from_file(FILE* f_in, FILE* f_out, char* codebook) {
	char c;
	while (!feof(f_in)) {
		// fscanf_s(f_in, "%c", &c, 1);
		c = getc(f_in);
		if(c == EOF) break;
		fprintf(f_out, "%s", codebook + (size_t)c * len_of_bits);
	}
}*/
void print_tree(freq_node* root){
    if ( root == NULL )
        return;
    print_tree(root->left);
    if (root->is_leaf)
        printf("( %c %lu )",root->symbol,root->freq);
    else
        printf(" %lu ",root->freq);
    print_tree(root->right);
    return;
}

void free_encode_tree(freq_node* root) {
	if (root == NULL) return;
	free_encode_tree(root->left);
	free_encode_tree(root->right);
	free(root);
	root = NULL;
}
int check_if_file( char* array){
    FILE *f;
    f = fopen( array,"r");
    if ( f == NULL )
        return 0;
    else
        fclose(f);
    return 1;
}

int check_if_dir( char* array){
    DIR* folder ;
    folder = opendir(array);
    if ( folder == NULL )
        return 0;
    else
        closedir(folder);
    return 1;
}
int encode_directory(char* input,char* output){
    char addr_buff[num];
	memset(addr_buff, 0, sizeof(addr_buff));
	char temp[num];
	memset(temp, 0, sizeof(temp));
	int i = 1;
    if(output[0] == 0){

        strcpy(addr_buff,input);
        strcpy(temp,input);
        strcat(temp,"\\");
        strcat(addr_buff,".zip");
        mkdir(addr_buff);

        DIR* folder = opendir(input);
        strcat(addr_buff,"\\");
        dp = readdir(folder);
        dp = readdir(folder);
        dp = readdir(folder);
        while(dp != NULL){

            strcat(temp,dp->d_name);
            strcat(addr_buff,dp->d_name);
            strcat(addr_buff,".coep@");
            if (check_if_file(temp)){
                i = encode(temp,addr_buff);
            }
            else if(check_if_dir(temp)){
                strcpy(addr_buff,input);
                strcat(addr_buff,".zip");
                strcat(addr_buff,"\\");
                strcat(addr_buff,dp->d_name);
                strcat(addr_buff,".zip");
                i = encode_directory(temp,addr_buff);
            }
            if ( i < 0)
                return -1;
            strcpy(temp,input);
            strcat(temp,"\\");
            strcpy(addr_buff,input);
            strcat(addr_buff,".zip");
            strcat(addr_buff,"\\");
            dp = readdir(folder);
        }
        closedir(folder);
    }
    else {
        mkdir(output);
        strcpy(addr_buff,output);
        strcat(addr_buff,"//");
        DIR* folder = opendir(input);
        strcpy(temp,input);
        strcat(temp,"\\");
        dp = readdir(folder);
        dp = readdir(folder);
        dp = readdir(folder);
        while(dp != NULL){

            strcat(temp,dp->d_name);
            strcat(addr_buff,dp->d_name);
            strcat(addr_buff,".coep@");
            if (check_if_file(temp)){
                i = encode(temp,addr_buff);
            }
            else if(check_if_dir(temp)){
                strcpy(addr_buff,output);
                strcat(addr_buff,"\\");
                strcat(addr_buff,dp->d_name);
                strcat(addr_buff,".zip");
                i = encode_directory(temp,addr_buff);
            }
            if ( i < 0)
                return -1;
            strcpy(temp,input);
            strcat(temp,"\\");
            strcpy(addr_buff,output);
            strcat(addr_buff,"\\");
            dp = readdir(folder);
        }
        closedir(folder);
    }
    return 1;


}
int encode(char* input_file ,char* output_file ){
    FILE *input ;

    input = fopen(input_file,"r");
    if (input == NULL )
        return 1;

    if (output_file[0] == 0){

        char output[200] ;
        strcpy(output,input_file);
        int pos;
        pos = strrchr(output,0) - output;
        output[pos] = '.';
        output[pos+1] = 'c';
        output[pos+2] = 'o';
        output[pos+3] = 'e';
        output[pos+4] = 'p';
        output[pos+5] = '@';
        output[pos+6] = 0;
        output_file = output;

    }

    freq_list l;
	init_freq_list(&l);
    unsigned int size =0;
    freq_node *p;
    for ( char c = getc(input) ; c != EOF ; c = getc(input)){
        p=search_in(l,c);

        if (p==NULL)
           insert_symbol(&l,c,1);
        else
            p->freq++;
        size++;
    }

    //frequency list created

    char codebook[no_of_symbols][len_of_bits];
	memset(codebook, 0, sizeof(codebook));

    freq_node* tree = create_tree(&l);
    generate_codebook(tree, 0, &codebook[0][0]);
	fclose(input);


    FILE* f_out = NULL;
	f_out = fopen(output_file, "w");
	if(f_out == NULL){
		printf("cannot open %s\n.exit.\n",output_file);
		return -1;
	}

	write_codebook(f_out, &codebook[0][0],size);
	fclose(f_out);

    input = fopen(input_file, "r");
	if(input == NULL){
		printf("cannot open %s\n.exit.\n", input_file);
		return -1;
	}
	f_out = fopen(output_file, "ab");
	if(f_out == NULL){
		printf("cannot open %s\n.exit.\n", output_file);
		return -1;
	}
	write_encode_stream_from_file(input, f_out, &codebook[0][0]);
	fclose(input);
	fclose(f_out);
	free_encode_tree(tree);

    return 0;
}




