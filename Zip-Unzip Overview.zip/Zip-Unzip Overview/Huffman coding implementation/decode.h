
typedef struct decode_node{
    struct decode_node*left ;
    struct decode_node*right;
    int is_leaf;
    char symbol;
}decode_node;

typedef decode_node* tree;
void free_decode_tree(decode_node* node);
int decode( char* input_filename,   char* output_filename);
int is_Kbit_set(unsigned char c ,int k);
int decode_directory(char* input , char* output);
