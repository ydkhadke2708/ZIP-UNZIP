#include <stdio.h>
#include <stdlib.h>
#include "freq_list.h"
#include "min_heap.h"

void init_pqueue(pqueue* q){
    *q = NULL;
}

void insert_pqueue(pqueue *q , freq_node* nn){
    if ( *q == NULL ){
        *q = nn;
        return;
    }
    freq_node* curr_node = NULL;
	freq_node* prev_node = NULL;

	curr_node = *q;
	while (curr_node && (curr_node->freq < nn->freq)){
        prev_node = curr_node;
		curr_node = curr_node->next;
	}
    if (curr_node == *q ){
		nn->next = *q;
		*q = nn;
	}
	else {
		prev_node->next = nn;
		nn->next = curr_node;
	}
}

void disp_pqueue(pqueue q) {
	printf("priority queue: ");
	freq_node *p = q;
	while (p) {
		printf("(%c, %lu),", p->symbol, p->freq);
		p = p->next;
	}
	printf("\n");
}

freq_node* pop_pqueue(pqueue* q) {
	if (*q == NULL) return NULL;
	freq_node* p = *q;
	*q = p->next;
	//printf("popped: (%c, %f)\n", p_node->symbol, p_node->freq);
	return p;
}

