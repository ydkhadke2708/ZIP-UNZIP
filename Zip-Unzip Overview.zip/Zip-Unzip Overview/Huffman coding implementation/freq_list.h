#define no_of_symbols 256
#define len_of_bits 50


typedef struct freq_node{
    unsigned long  freq;
    char symbol;
    struct freq_node* next,*left,*right,*parent;
    int is_leaf;
}freq_node;

typedef freq_node* freq_list;

int is_empty_freq_list(freq_list l);

void init_freq_list(freq_list *l);

void insert_symbol(freq_list *l, char symbol , int d );
int freq_list_length(freq_list l);

void destroy(freq_list *l);


void traverse( freq_list l);
freq_node* search_in(freq_list l, char c);



