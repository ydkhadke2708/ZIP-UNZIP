#define num 100
int encode(char *input ,char* output_file );

int encode_directory(char* input,char* output);
int check_if_file( char* array);
struct dirent *dp;

int check_if_dir( char* array);
