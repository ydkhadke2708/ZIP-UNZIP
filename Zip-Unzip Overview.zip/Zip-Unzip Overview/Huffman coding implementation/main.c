#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "data_compression.h"
#include "decode.h"
#include <dirent.h>
#include <string.h>

int main(int argc,char* argv[])
{

    const char* usage = "help for program\n"\
						"encode: program -e filename e\n"\
                        "decode: program -d encoded_filename \n";

	if(argc != 3){
		printf("%s", usage);exit(1);
	}

	char input_filename_buff[num];
	char output_filename_buff[num];
	memset(input_filename_buff, 0, sizeof(input_filename_buff));
	memset(output_filename_buff, 0, sizeof(output_filename_buff));
	char addr_buff[num];
	memset(addr_buff, 0, sizeof(addr_buff));
	char temp[num];
	memset(temp, 0, sizeof(temp));
    int encoding = 0;
	int i = 1;

    if(argv[i][0] == '-'){
			switch (argv[i][1])
			{
			case 'e':
			        encoding = 1;
			        if(i+1 < argc) {
						strcpy(input_filename_buff, argv[++i]);
						input_filename_buff[num - 1] = 0;
					}
					else{
						printf("%s", usage);exit(1);
					}
					break;
			case 'd':
			        if(encoding) {
						printf("%s", usage);exit(1);
					}
			        if(i+1 < argc){
						strcpy(input_filename_buff, argv[++i]);
						input_filename_buff[num - 1] = 0;
					}
					else{
						printf("%s", usage);exit(1);
					}
			        break;
			default:
			        printf("%s", usage);exit(1);
				    break;
			}

    }
    else{
        printf("%s", usage);exit(1);
    }

    int response = 0;

	if(encoding){
        if (check_if_file(input_filename_buff))
            response = 	encode(input_filename_buff, output_filename_buff);
        else
            response = encode_directory(input_filename_buff,output_filename_buff);
	}
	else{
        if (check_if_file(input_filename_buff))
            response = 	decode(input_filename_buff, output_filename_buff);
        else
            response = decode_directory(input_filename_buff,output_filename_buff);
	}

    if(response < 0){
		printf("operation failed.\n");
		exit(-1);
	}
	else
        printf("Successfull .\n");



    return 0;
}
