#include <stdio.h>
#include <stdlib.h>
#include "freq_list.h"

void init_freq_list(freq_list *l){
    *l = NULL;
    return;
}

int is_empty_freq_list(freq_list l){
    if(l == NULL)
        return 1;
    else
        return 0;
 }

 void insert_symbol(freq_list *l, char symbol , int d ){
    freq_node *p, *newnode;
    newnode = (freq_node*)malloc(sizeof(freq_node));
    if(newnode){
        newnode->freq = d;
        newnode->symbol = symbol ;
        newnode->next = NULL;
        newnode->left =newnode->right = newnode->parent = NULL;
        newnode->is_leaf = 1;
    }
    else return;
    if(*l == NULL){
        *l = newnode;
        return;
    }
    p = *l;
    while(p -> next) {
       p = p->next;
    }
    p->next = newnode;
    return;
}

int freq_list_length(freq_list l){
    int len = 0;
    freq_node *p  = l;
    while(p){
        len++;
        p = p->next;
    }
    return len;
}

void destroy(freq_list *l){
    freq_node *p = *l;
    freq_node *q;
    while(p){
        q = p;
        p = p->next;
        //////////////////////////////////////////////////////////////
        free(q);
    }
    *l = NULL;
    return ;
}




void traverse( freq_list l){
    freq_node *p;
    p = l;
    while(p){
        printf("( %c ", p->symbol);
        printf(" %lu ",p->freq);
        printf(" ) ");
        p = p->next;
    }
    printf("\n");
    return;
}

freq_node* search_in(freq_list l , char c){
    freq_node *p ;
    p = l;

    while ( p ){
        if ( c == p->symbol)
            return p;
        p = p->next;
    }
    return NULL;
}


