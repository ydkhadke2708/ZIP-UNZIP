
/*
typedef struct heap{
    freq_node *array;
    int top , rear ,size ;
}heap;

void init_heap( heap *h , int size );
void insert_heap( heap* h , freq_node nn);
freq_node delete_heap(heap *h);
void destroy_heap(heap *h);


*/
typedef freq_node* pqueue;
void init_pqueue(pqueue* q);
void disp_pqueue(pqueue q);
freq_node* pop_pqueue(pqueue* q);
void insert_pqueue(pqueue *q , freq_node* nn);
