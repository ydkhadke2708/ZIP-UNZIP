#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <dirent.h>
#include "data_compression.h"
#include "freq_list.h"
#include "decode.h"
decode_node* get_decode_node(){
    decode_node *newnode = (decode_node*)malloc(sizeof(decode_node));

    if(newnode){
        newnode->symbol = '\0';
        newnode->left =newnode->right = NULL ;
        newnode->is_leaf = 0;
    }
    else
        return NULL;
    return newnode;
}

void free_decode_tree(decode_node* nn) {
	if (nn == NULL) return;
	free_decode_tree(nn->left);
	free_decode_tree(nn->right);
	free(nn);
	nn = NULL;
}


int decode_directory(char* input , char* output){
    char addr_buff[num];
	memset(addr_buff, 0, sizeof(addr_buff));
	char temp[num];
	memset(temp, 0, sizeof(temp));

	char temp2[num];
	memset(temp2,0,sizeof(temp2));
	char temp3[num];
	memset(temp2,0,sizeof(temp3));
	int i = 1,pos = 0;
    if (output[0] == 0){
        strcpy(addr_buff,input);
        pos = strrchr(addr_buff,'.') - addr_buff;
        if (addr_buff[pos+1] != 'z' || addr_buff[pos+2] != 'i' || addr_buff[pos+3] !='p' || addr_buff[pos+4] != 0)
            return 1;
        addr_buff[pos]=0;
        mkdir(addr_buff);
        strcat(addr_buff,"\\");

        strcpy(temp2,addr_buff);

        strcpy(temp,input);
        strcat(temp,"\\");

        DIR* folder = opendir(input);
        if ( folder == NULL)
            return -1;
        dp = readdir(folder);
        dp = readdir(folder);
        dp = readdir(folder);

        while(dp != NULL ){
            strcat(temp,dp->d_name);

            if (check_if_file(temp)){
                strcpy(temp3,dp->d_name);
                pos = strrchr(temp3,'.')-temp3;
                if (temp3[pos+1] != 'c' || temp3[pos+2] != 'o' || temp3[pos+3] !='e' || temp3[pos+4] != 'p' || temp3[pos+5] != '@' || temp3[pos+6]!= 0 )
                    return 1;
                temp3[pos] = 0;
                strcat(addr_buff,temp3);
                i = decode(temp,addr_buff);
            }
            else if(check_if_dir(temp)){
                strcat(addr_buff,dp->d_name);
                pos = strrchr(addr_buff,'.') - addr_buff ;
                if (addr_buff[pos+1] != 'z' || addr_buff[pos+2] != 'i' || addr_buff[pos+3] !='p' || addr_buff[pos+4] != 0)
                    return 1;
                addr_buff[pos] = 0;
                i = decode_directory(temp,addr_buff);
            }
            if ( i < 0)
                return -1;
            strcpy(addr_buff,temp2);
            strcpy(temp,input);
            strcat(temp,"\\");
            dp = readdir(folder);
        }
        closedir(folder);
    }
    else{
        mkdir(output);
        strcpy(addr_buff,output);
        strcat(addr_buff,"//");
        pos = strrchr(input,'.') - input;
        if (input[pos+1] != 'z' || input[pos+2] != 'i' || input[pos+3] !='p' || input[pos+4] != 0)
            return 1;
        DIR* folder = opendir(input);
        if (folder == NULL )
            return 1;
        strcpy(temp,input);
        strcat(temp,"\\");
        dp = readdir(folder);
        dp = readdir(folder);
        dp = readdir(folder);
        while(dp != NULL ){
            strcat(temp,dp->d_name);
            if (check_if_file(temp)){
                strcpy(temp3,dp->d_name);
                pos = strrchr(temp3,'.')-temp3;
                if (temp3[pos+1] != 'c' || temp3[pos+2] != 'o' || temp3[pos+3] !='e' || temp3[pos+4] != 'p' || temp3[pos+5] != '@' || temp3[pos+6]!= 0 )
                    return 1;
                temp3[pos] = 0;
                strcat(addr_buff,temp3);
                i = decode(temp,addr_buff);
            }
            else if(check_if_dir(temp)){
                strcat(addr_buff,dp->d_name);
                pos = strrchr(addr_buff,'.') - addr_buff ;
                if (addr_buff[pos+1] != 'z' || addr_buff[pos+2] != 'i' || addr_buff[pos+3] !='p' || addr_buff[pos+4] != 0)
                    return 1;
                addr_buff[pos] = 0;
                i = decode_directory(temp,addr_buff);
            }
            if ( i < 0)
                return -1;
            strcpy(temp,input);
            strcat(temp,"\\");
            strcpy(addr_buff,output);
            strcat(addr_buff,"\\");
            dp = readdir(folder);
        }
        closedir(folder);
    }
    return 1;
}
unsigned long int create_decode_tree(FILE* fp, decode_node* root_decode) {
	char symbol=0;
	char strcode[len_of_bits];
	int index=0, length=0;
	int num_input=0;
	unsigned long int size =0;
    fscanf(fp,"%lu\n",&size);
	decode_node* curr_node = NULL;
	while (!feof(fp)) {
		memset(strcode, 0, sizeof(strcode));
		num_input = fscanf(fp, "#%c %s\n", &symbol, strcode);
		if (num_input != 2) {
			break;
		}
		//printf("reading:(%c,%s)successfully\n", symbol, strcode);

		curr_node = root_decode;
		length = strlen(strcode);


		for (index = 0; index < length; index++) {
			if (strcode[index] == '0') {
				if (curr_node->left == NULL){
					curr_node->left = get_decode_node();
				}
				curr_node = curr_node->left;
			}
			else if(strcode[index] == '1') {
				if (curr_node->right == NULL) {
					curr_node->right = get_decode_node();
				}
				curr_node = curr_node->right;
			}
			else {
				printf("unexpected char %c\n", strcode[index]);
				assert(0);
			}
		}

		assert(curr_node->is_leaf == 0);
		// at last assign the symbol to the leaf node
		curr_node->is_leaf = 1;
		curr_node->symbol = symbol;
		//printf("successfully inserted symbol:(%c,%s)\n", symbol, strcode);
	}
    return size;
}

int is_Kbit_set(unsigned char c ,int k){
    if ( c & (1 << (k-1)))
        return 1;
    else
        return 0;
}


void decode_using_tree( FILE* fin, FILE* fout, decode_node* root,unsigned long int size){

    unsigned char c = 0;
    unsigned long int m = 0;
    int k;
    decode_node* curr = root;
    while (!feof(fin)){
        c = getc(fin);
		if(c == EOF) break;
		k = 8;
        while ( k > 0 ){
            if (is_Kbit_set(c,k))
                curr = curr->right;
            else if (is_Kbit_set(c,k) == 0)
                curr = curr->left;
            else
                assert(0);
            if (curr->is_leaf) {
                fprintf(fout, "%c", curr->symbol);
                curr = root;
                m++;
                if ( m == size   )
                    return;
            }
            k--;
        }
    }
}

/*void decode_using_tree( FILE* fin, FILE* fout, decode_node* root){

    char c = 0;
    decode_node* curr = root;
    while (!feof(fin)){
        c = getc(fin);
		if(c == EOF) break;

		if (c == '0') {
			curr = curr->left;
		}
		else if (c == '1') {
			curr = curr->right;
		}
		else {
			printf("\nchar(%c)rather than 1 or 0 appears\n", c);
			assert(0);
		}
		if (curr->is_leaf) {
			fprintf(fout, "%c", curr->symbol);
			curr = root;
		}
    }
}*/
int decode( char* input_filename,   char* output_filename){

	FILE* f_in = NULL;
	FILE* f_out = NULL;
    unsigned long size = 0;
	f_in = fopen(input_filename, "rb");
	if(f_in == NULL){
		printf("cannot open %s\n.exit.\n", input_filename);
		return -1;
	}

	if (output_filename[0] == 0){
        char output[200] ;
        strcpy(output,input_filename);
        int pos;
        pos = strrchr(output,'.') - output;
        output[pos] = 0;
        output_filename = output;

    }
	decode_node* tree_root= get_decode_node();
	size = create_decode_tree(f_in, tree_root);



////////////////////////////////////////////////////////////////////now decoding


	f_out = fopen(output_filename, "w");
	if(f_out == NULL){
		printf("cannot open %s\n.exit.\n", output_filename);
		return -1;
	}
	decode_using_tree(f_in, f_out, tree_root,size);
	fclose(f_in);
	f_in = NULL;
	fclose(f_out);
	f_out = NULL;
    free_decode_tree(tree_root);
	return 0;
}
